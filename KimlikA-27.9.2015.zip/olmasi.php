<?php
/**
 * Created by PhpStorm.
 * User: Emre
 * Date: 26.9.2015
 * Time: 17:27
 */
$link='http://'.$_SERVER['HTTP_HOST'].'/Kimlik';
$uyarimizA=' | <font color="red">albüm</font>';
$uyarimizK=' | <font color="red">kimlik</font>';
?>