<hr />
<div class="row">
    <div class="col-xs-6"><div style="text-align:left;"><sub>Created by EmreK. </div></div>
    <div class="col-xs-6"><div style="text-align:right;"><sub><a target="_blank" href="http://www.globalmedia.com.tr/">GlobalMedia <sup>®</sup></a> </sub> </div></div>
</div>
</div> <!-- /container -->

<script src="<?php echo $link; ?>/dist/js/vendor/video.js"></script>
<script src="<?php echo $link; ?>/dist/js/flat-ui.min.js"></script>
<script src="<?php echo $link; ?>/docs/assets/js/application.js"></script>


</body>
</html>
            